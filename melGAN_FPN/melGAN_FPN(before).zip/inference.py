import os
import glob
import tqdm
import torch
import argparse
from scipy.io.wavfile import write

from model.generator import Generator
from utils.hparams import HParam, load_hparam_str

import numpy as np


MAX_WAV_VALUE = 32768.0
    
def main(args):

    tacotron2 = torch.hub.load('nvidia/DeepLearningExamples:torchhub', 'nvidia_tacotron2')
    tacotron2 = tacotron2.to('cuda')
    tacotron2.eval()

    # preprocessing
    sequence = np.array(tacotron2.text_to_sequence(args.text, ['english_cleaners']))[None, :]
    sequence = torch.from_numpy(sequence).to(device='cuda', dtype=torch.int64)

    #with torch.no_grad():
        #_, mel, _, _ = tacotron2.infer(sequence)
        #np.save('{}/{}.mel'.format('test/result', 'noa'), mel.numpy(), allow_pickle=False)



    checkpoint = torch.load(args.checkpoint_path)
    if args.config is not None:
        hp = HParam(args.config)
    else:
        hp = load_hparam_str(checkpoint['hp_str'])

    model = Generator(hp.audio.n_mel_channels).cuda()
    model.load_state_dict(checkpoint['model_g'])
    model.eval(inference=False)

    with torch.no_grad():
        _, mel, _, _ = tacotron2.infer(sequence)
        print(mel)
        audio = model.inference(mel)
        audio = audio.cpu().detach().numpy()

        #out_path = melpath.replace('.mel', '_reconst_%04d.wav' % checkpoint['epoch'])
        out_path = args.input_folder + 'hello.wav'
        write(out_path, hp.audio.sampling_rate, audio)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-c', '--config', type=str, default=None,
                        help="yaml file for config. will use hp_str from checkpoint if not given.")
    parser.add_argument('-p', '--checkpoint_path', type=str, default='chkpt/result/result_0250.pt',
                        help="path of checkpoint pt file for evaluation")
    parser.add_argument('-i', '--input_folder', type=str, default='test',
                        help="directory of mel-spectrograms to invert into raw audio. ")
    parser.add_argument('-t', '--text', type=str, required = True,
                        help="directory of mel-spectrograms to invert into raw audio. ")
    args = parser.parse_args()

    main(args)
