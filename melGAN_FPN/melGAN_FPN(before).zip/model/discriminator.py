import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.utils import weight_norm
import numpy as np

def WNConv1d(*args, **kwargs):
    return weight_norm(nn.Conv1d(*args, **kwargs))

def WNConvTranspose1d(*args, **kwargs):
    return weight_norm(nn.ConvTranspose1d(*args, **kwargs))

class Discriminator(nn.Module):
    def __init__(self):
        super(Discriminator, self).__init__()

        self.discriminator = nn.ModuleList([
            nn.Sequential(
                nn.ReflectionPad1d(7),
                nn.utils.weight_norm(nn.Conv1d(1, 16, kernel_size=15, stride=1)),
                nn.LeakyReLU(0.2, inplace=True),
            ),
            nn.Sequential(
                nn.utils.weight_norm(nn.Conv1d(16, 32, kernel_size=21, stride=2, padding=10, groups=4)),
                nn.LeakyReLU(0.2, inplace=True),
            ),
            nn.Sequential(
                nn.utils.weight_norm(nn.Conv1d(32, 64, kernel_size=21, stride=2, padding=10, groups=8)),
                nn.LeakyReLU(0.2, inplace=True),
            ),
            nn.Sequential(
                nn.utils.weight_norm(nn.Conv1d(64, 128, kernel_size=21, stride=2, padding=10, groups=16)),
                nn.LeakyReLU(0.2, inplace=True),
            ),
            nn.Sequential(
                nn.utils.weight_norm(nn.Conv1d(128, 256, kernel_size=21, stride=2, padding=10, groups=32)),
                nn.LeakyReLU(0.2, inplace=True),
            ),
            
            #nn.Sequential(
                #nn.utils.weight_norm(nn.Conv1d(1024, 1024, kernel_size=41, stride=4, padding=20, groups=256)),
                #nn.LeakyReLU(0.2, inplace=True),
            #),
            
        ])

        #self.latlayer_1024 = WNConv1d(1024, 1024, kernel_size=1, stride=1, padding=0)
        self.latlayer_128 = WNConv1d(128, 256, kernel_size=1, stride=1, padding=0)
        self.latlayer_64 = WNConv1d( 64, 256, kernel_size=1, stride=1, padding=0)
        self.latlayer_32 = WNConv1d( 32, 256, kernel_size=1, stride=1, padding=0)
        self.latlayer_16 = WNConv1d( 16, 256, kernel_size=1, stride=1, padding=0)

        self.top = nn.Sequential(nn.LeakyReLU(0.2),WNConvTranspose1d(256,256,kernel_size = 21,stride=2,padding=10,output_padding=1,))
        self.final = WNConv1d(256, 1, kernel_size=3, stride=1, padding=1)

    def forward(self, x):
        '''
            returns: (list of 6 features, discriminator score)
            we directly predict score without last sigmoid function
            since we're using Least Squares GAN (https://arxiv.org/abs/1611.04076)
        '''
        bottom_up = list()
        top_down = list()
        for module in self.discriminator:
            x = module(x)
            #print(x.shape)
            bottom_up.append(x)
        #print(self.top2(bottom_up[3]).shape)
        
        result = self.top(bottom_up[4]) + self.latlayer_128(bottom_up[3])
        top_down.append(result)
        
        result = self.top(result) + self.latlayer_64(bottom_up[2])
        top_down.append(result)
        
        result = self.top(result) + self.latlayer_32(bottom_up[1])
        top_down.append(result)

        result = self.top(result) + self.latlayer_16(bottom_up[0])
        top_down.append(result)

        result = self.final(result)    
        top_down.append(result)
        


        return top_down


if __name__ == '__main__':
    model = Discriminator()

    x = torch.randn(3, 1, 22050)
    print(x.shape)

    features, score = model(x)
    for feat in features:
        print(feat.shape)
    print(score.shape)

    pytorch_total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(pytorch_total_params)